<?php

class WPML_TM_Translation_Status_Display {

	private $language_pairs = array();
	private $current_lang;
	private $user_id        = array();
	private $user_is_admin;
	private $statuses       = array();
	private $editor_is_default;

	public function __construct( $user_id, $user_is_admin, $language_pairs, $current_lang, $active_languages ) {
		$this->user_id           = $user_id;
		$this->language_pairs    = $language_pairs;
		$this->user_is_admin     = $user_is_admin;
		$this->current_lang      = $current_lang;
		$this->active_langs      = $active_languages;
		$this->editor_is_default = icl_get_setting( 'doc_translation_method' );
		add_action( 'wpml_cache_clear', array( $this, 'init' ), 11, 0 );
	}

	public function init( $refresh = true ) {
		add_filter( 'wpml_icon_to_translation', array( $this, 'filter_status_icon' ), 10, 3 );
		add_filter( 'wpml_link_to_translation', array( $this, 'filter_status_link' ), 10, 4 );
		add_filter( 'wpml_text_to_translation', array( $this, 'filter_status_text' ), 10, 4 );

		if ( $refresh === true ) {
			$this->user_is_admin = current_user_can( 'manage_options' );
		}
	}

	private function maybe_load_stats( $trid ) {
		if ( !isset( $this->statuses[ $trid ] ) ) {
			global $wpdb;

			$stats                   = $wpdb->get_results (
				$wpdb->prepare (
					"SELECT st.status, l.code, st.translator_id, st.translation_service
								FROM {$wpdb->prefix}icl_languages l
								LEFT JOIN {$wpdb->prefix}icl_translations i
									ON l.code = i.language_code
								JOIN {$wpdb->prefix}icl_translation_status st
									ON i.translation_id = st.translation_id
								WHERE l.active = 1
									AND i.trid = %d
									OR i.trid IS NULL",
					$trid
				),
				ARRAY_A
			);
			$this->statuses[ $trid ] = array();
			foreach ( $stats as $element ) {
				$this->statuses[ $trid ][ $element[ 'code' ] ] = $element;
			}
		}
	}

	private function is_remote( $trid, $lang ) {

		return isset( $this->statuses[ $trid ][ $lang ][ 'translation_service' ] )
		       && (bool) $this->statuses[ $trid ][ $lang ][ 'translation_service' ] !== false
		       && $this->statuses[ $trid ][ $lang ][ 'translation_service' ] !== 'local';
	}

	private function is_in_progress( $trid, $lang ) {

		return isset( $this->statuses[ $trid ][ $lang ][ 'status' ] )
		       && ( $this->statuses[ $trid ][ $lang ][ 'status' ] == ICL_TM_IN_PROGRESS
		            || $this->statuses[ $trid ][ $lang ][ 'status' ] == ICL_TM_WAITING_FOR_TRANSLATOR );
	}

	private function is_wrong_translator( $trid, $lang ) {

		return isset( $this->statuses[ $trid ][ $lang ][ 'translator_id' ] )
		       && $this->statuses[ $trid ][ $lang ][ 'translator_id' ] != $this->user_id && !$this->user_is_admin;
	}

	private function is_in_basket( $trid, $lang ) {
		$status_helper = wpml_get_post_status_helper ();

		return $status_helper->get_status ( false, $trid, $lang ) === ICL_TM_IN_BASKET;
	}

	private function is_lang_pair_allowed( $lang ) {

		return $this->user_is_admin
		       || isset( $this->language_pairs[ $this->current_lang ][ $lang ] );
	}

	private function exists( $trid, $lang ) {

		return isset( $this->statuses[ $trid ][ $lang ] );
	}

	public function filter_status_icon( $icon, $lang, $trid ) {
		$this->maybe_load_stats ( $trid );

		if ( ( $this->is_remote ( $trid, $lang )
		       ||  $this->is_wrong_translator ( $trid, $lang )
		     )
		     && $this->is_in_progress ( $trid, $lang )
		) {
			$icon = 'in-progress.png';
		} elseif ( $this->is_in_basket ( $trid, $lang )
		           || ( !$this->is_lang_pair_allowed ( $lang ) && $this->exists ( $trid, $lang ) )
		) {
			$icon = 'edit_translation_disabled.png';
		} elseif ( !$this->is_lang_pair_allowed ( $lang ) && !$this->exists ( $trid, $lang ) ) {
			$icon = 'add_translation_disabled.png';
		}

		return $icon;
	}

	public function filter_status_text( $text, $original_post_id, $lang, $trid ) {
		global $wpml_post_translations;

		$this->maybe_load_stats ( $trid );

		if ( $this->is_remote ( $trid, $lang ) ) {
			if ( $wpml_post_translations->get_source_lang_code( $original_post_id ) === $lang ) {
				$text = __ (
					"You can't edit this document, because translations of this document are currently in progress.",
					'sitepress'
				);
			} else {
				$text = sprintf (
					__ (
						"You can't edit this translation, because this translation to %s is already in progress.",
						'sitepress'
					),
					$this->active_langs[ $lang ][ 'display_name' ]
				);
			}
		} elseif ( $this->is_in_basket ( $trid, $lang ) ) {
			$text = __ (
				'Cannot edit this item, because it is currently in the translation basket.',
				'sitepress'
			);
		}

		return $text;
	}

	public function filter_status_link( $link, $post_id, $lang, $trid ) {
		global $wpml_post_translations;
		$this->maybe_load_stats( $trid );

		if ( ( $this->is_remote( $trid, $lang ) && $this->is_in_progress( $trid, $lang ) )
			 || $this->is_in_basket( $trid, $lang )
			 || ! $this->is_lang_pair_allowed(
				$lang
			)
		) {
			$link = '###';
		} elseif ( ( $this->is_in_progress( $trid, $lang ) && ! $this->is_remote( $trid, $lang )
					 || $this->editor_is_default && $this->exists( $trid, $lang ) )
				   && $wpml_post_translations->get_source_lang_code( $post_id ) !== $lang
		) {
			global $iclTranslationManagement;

			$link = 'admin.php?page=' . WPML_TM_FOLDER . '/menu/' . 'translations-queue.php&job_id='
					. $iclTranslationManagement->get_translation_job_id( $trid, $lang );
		} elseif ( $this->editor_is_default && ! $this->exists( $trid, $lang ) ) {
			$link = 'admin.php?page='
					. WPML_TM_FOLDER . '/menu/translations-queue.php&trid=' . $trid
					. '&language_code=' . $lang . '&source_language_code=' . $this->current_lang;
		}

		return $link;
	}
}